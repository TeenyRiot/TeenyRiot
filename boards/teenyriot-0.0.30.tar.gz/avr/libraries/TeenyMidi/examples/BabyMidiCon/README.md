## BabyconMidiUSB

![babymidipin.png](https://raw.githubusercontent.com/ATtinyTeenageRiot/BabyconMidiUSB/master/babymidipin.png)

## Installation



## Contributors



## Credits


